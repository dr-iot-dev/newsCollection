"""News Weave application."""
